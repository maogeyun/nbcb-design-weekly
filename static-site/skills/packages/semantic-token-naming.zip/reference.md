# 语义令牌命名参考

## 语义层 — 颜色角色（role）

| 角色 | 用途 |
|------|------|
| `action` | 可点击主/次操作（按钮、链接） |
| `surface` | 页面/卡片/面板背景层级 |
| `feedback` | 成功 / 警告 / 错误 / 信息 |
| `border` | 分隔线、描边 |
| `text` | 正文、标题、辅助文案 |
| `overlay` | 遮罩、浮层 |
| `focus` | 焦点环 |

**属性（property）**：`bg` · `fg` · `border` · `icon` · `ring`

**变体（variant）**：`default` · `subtle` · `strong` · `inverse` · `primary` · `secondary`

## 语义层 — 间距 / 尺寸

| 范围（scope） | 示例 |
|---------------|------|
| `layout` | 页面级 gutter、section gap |
| `component` | 组件内 padding、gap |
| `component-{name}` | 特定组件，如 `component-card` |

**属性**：`padding` · `gap` · `margin` · `radius` · `size`

**尺度**：`xs` · `sm` · `md` · `lg` · `xl`（或项目 numeric scale，但语义层仍用尺度名）

## 组件层命名模板

```
--dls-color-component-{component}-{property}-{variant}-{state}
--dls-space-component-{component}-{property}-{size}
```

| 组件 | 示例 |
|------|------|
| button | `--dls-color-component-button-bg-primary-default` |
| input | `--dls-color-component-input-border-default` |
| card | `--dls-space-component-card-padding-md` |

**规则**：组件令牌 → 仅引用语义令牌；禁止跨组件复用同名组件令牌。

## 状态层 — Oklch 推导（默认）

从 `--*-default` 基色（Oklch）推导，不手选 hex：

| 状态 | 典型调整 |
|------|----------|
| hover | L + 0.04 ~ 0.08 |
| pressed | L − 0.06 ~ 0.10，C − 0.02 |
| disabled | L + 0.12，C × 0.5，可选 A × 0.5 |
| focus | 复用 `focus` 语义 ring 令牌 |

命名：`--dls-color-component-button-bg-primary-hover` 等，值由脚本或 CSS `color-mix(in oklch, …)` 生成。

## 级联引用链示例

```css
/* 语义 */
--dls-color-action-bg-primary: oklch(0.55 0.18 250);
--dls-color-action-bg-primary-hover: oklch(from var(--dls-color-action-bg-primary) calc(l + 0.06) c h);

/* 组件 */
--dls-color-component-button-bg-primary-default: var(--dls-color-action-bg-primary);
--dls-color-component-button-bg-primary-hover: var(--dls-color-action-bg-primary-hover);
```

## 审计清单

- [ ] 语义层无 `--blue-*` / `--gray-*` / `--color-1` 等外观或序号名
- [ ] 无 `--card-bg` 等泛化冲突名（带组件或角色前缀）
- [ ] 组件层无裸 hex / px（全部 `var()` 语义层）
- [ ] hover / pressed / disabled 可追溯到 Oklch 基色
- [ ] 每个令牌能一句话说明「何时用」
- [ ] Figma Variables 集合顺序：Semantic → Component →（States 绑定 Component）

## 重命名迁移模板

| 旧名 | 问题 | 建议新名 |
|------|------|----------|
| `--blue-500` | 原始值泄露 | `--dls-color-action-bg-primary` |
| `--color-1` | 不透明 | `--dls-color-surface-default` |
| `--card-bg` | 语义冲突 | `--dls-color-surface-raised-default` 或 `--dls-color-component-card-bg-default` |
