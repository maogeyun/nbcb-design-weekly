# coffer-design — Tokens

## 0. PRIMITIVES

### Color Ramps

**Neutral** (warm enterprise gray)

| Step | Hex | Use |
|------|-----|-----|
| 50 | `#FAFAFA` | Card surface, table header |
| 100 | `#F7F7F9` | Page background |
| 200 | `#E9E9E9` | Borders, dividers |
| 300 | `#DDDDDD` | Strong borders, input focus ring base |
| 400 | `#BFBFBF` | Placeholder text |
| 500 | `#999999` | Tertiary text, timestamps |
| 600 | `#555555` | Secondary labels |
| 700 | `#333333` | Body secondary |
| 800 | `#222222` | Primary text, headings |
| 900 | `#1A1A1A` | Dark mode surfaces |
| 950 | `#141414` | Dark mode canvas |

**Brand** (NBCB warm orange)

| Step | Hex |
|------|-----|
| 50 | `#FFF6EA` |
| 100 | `#FFD397` |
| 200 | `#FFB859` |
| 300 | `#FFA62F` |
| 400 | `#E5952A` |
| 500 | `#FFA62F` — primary accent |
| 600 | `#E5952A` |
| 700 | `#CC8524` |
| 800 | `#B3741F` |
| 900 | `#996319` |
| 950 | `#805214` |

**Status Colors**

| Color | 50 (bg tint) | 500 (foreground) | 900 (dark tint) |
|-------|-------------|-----------------|-----------------|
| Red | `#FEF2F2` | `#F26D44` | `#7F1D1D` |
| Green | `#F0FDF4` | `#52D393` | `#14532D` |
| Amber | `#FFFBEB` | `#F7D519` | `#78350F` |

**Info blue:** `#1890FF` — links, chart series, non-destructive info

### Spacing Primitives

`0, 2, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64, 96`

### Radii Primitives

`0, 2, 4, 8, 12, 999`

---

## 1. TYPOGRAPHY

### Font Stack

| Role | Font | Fallback | Weight | Use |
|------|------|----------|--------|-----|
| **Display** | `"Noto Sans SC"` | `"PingFang SC", "Microsoft YaHei", sans-serif` | 600 | Page titles, section headers |
| **Body / UI** | `"Noto Sans SC"` | `"PingFang SC", "Microsoft YaHei", sans-serif` | 400 | Body, labels, table cells |
| **Mono / Code** | `"JetBrains Mono"` | `ui-monospace, monospace` | 400 | Fund codes, amounts, IDs |

### Mono Font Rules

**`mono_for_code`: true** · **`mono_for_metrics`: true**

NBCB FIPS is financial operations software — fund codes, CNY amounts, percentages, and project IDs render in mono. Prose and labels stay in Noto Sans SC.

### Type Scale

| Token | Size | Line Height | Letter Spacing | Weight | Use |
|-------|------|-------------|----------------|--------|-----|
| `--display` | 28px | 1.25 | 0 | 600 | Page titles |
| `--h1` | 24px | 1.35 | 0 | 600 | Section headings |
| `--h2` | 20px | 1.4 | 0 | 600 | Card titles |
| `--h3` | 16px | 1.5 | 0 | 600 | Subsection titles |
| `--body` | 14px | 1.5715 | 0 | 400 | Body text, table cells |
| `--body-sm` | 13px | 1.5 | 0 | 400 | Input text, compact labels |
| `--caption` | 12px | 1.5 | 0 | 400 | Timestamps, footnotes |
| `--label` | 12px | 1.5 | 0 | 500 | Table headers, form labels |

### Typographic Rules

- Active tab: weight 700 at 14px. Inactive tab: weight 500 at `#999`.
- KPI big numbers: mono 24px weight 500.
- Never use display size inside table cells.

---

## 2. COLOR SYSTEM (Semantic Tokens)

### Primary Mode (Light)

| Token | Hex | Role |
|-------|-----|------|
| `--background` | `#F7F7F9` | Page background |
| `--bg` | `var(--background)` | Shorthand alias |
| `--surface1` | `#FAFAFA` | Cards, elevated containers |
| `--surface2` | `#E9E9E9` | Nested groups, sidebar dividers |
| `--surface3` | `#DDDDDD` | Input wells, disabled areas |
| `--border` | `#E9E9E9` | Subtle dividers |
| `--border-visible` | `#DDDDDD` | Input borders, table rules |
| `--text1` | `#222222` | Primary text |
| `--text2` | `#333333` | Secondary text |
| `--text3` | `#555555` | Tertiary text |
| `--text4` | `#999999` | Disabled, placeholders |
| `--accent` | `#FFA62F` | Primary CTA, active nav |
| `--accent-subtle` | `#FFF6EA` | Tinted accent backgrounds |
| `--success` | `#52D393` | Positive states |
| `--warning` | `#F7D519` | Caution states |
| `--error` | `#F26D44` | Destructive/error |

### Secondary Mode (Dark)

| Token | Hex | Role |
|-------|-----|------|
| `--background` | `#141414` | Page background |
| `--surface1` | `#1A1A1A` | Cards |
| `--surface2` | `#222222` | Nested surfaces |
| `--surface3` | `#333333` | Input wells |
| `--border` | `#222222` | Subtle dividers |
| `--border-visible` | `#333333` | Strong borders |
| `--text1` | `#FAFAFA` | Primary text |
| `--text2` | `#999999` | Secondary text |
| `--text3` | `#555555` | Tertiary text |
| `--text4` | `#333333` | Disabled |
| `--accent` | `#FFA62F` | Primary accent |
| `--accent-subtle` | `#805214` | Tinted accent bg |
| `--success` | `#52D393` | Positive |
| `--warning` | `#F7D519` | Caution |
| `--error` | `#F26D44` | Error |

### Accent & Status Tints

| Token | Light | Dark | Usage |
|-------|-------|------|-------|
| `--accent-subtle` | `#FFF6EA` | `#805214` | Selected nav, hover bg |
| `--success-bg` | `#F0FDF4` | `#14532D` | Success row tint |
| `--warning-bg` | `#FFFBEB` | `#78350F` | Warning row tint |
| `--error-bg` | `#FEF2F2` | `#7F1D1D` | Error row tint |

### Color Usage Rules

- Orange for one primary action per section. Secondary actions use outline orange or ghost.
- Green/red for delta indicators only — not for decorative badges.
- Table zebra: `#FAFAFA` alternating rows on white.

---

## 3. SPACING

### Scale (8px base)

| Token | Value | Use |
|-------|-------|-----|
| `--space-2xs` | 2px | Optical adjustments |
| `--space-xs` | 4px | Icon-to-label gaps |
| `--space-sm` | 8px | Component internal padding |
| `--space-md` | 16px | Card padding, standard gaps |
| `--space-lg` | 24px | Section spacing |
| `--space-xl` | 32px | Major section breaks |
| `--space-2xl` | 48px | Page section divisions |
| `--space-3xl` | 64px | Hero breathing room |
| `--space-4xl` | 96px | Login page vertical rhythm |

---

## 4. BORDERS & RADII

| Token | Value | Use |
|-------|-------|-----|
| `--radius-element` | 2px | Checkboxes, small icons |
| `--radius-control` | 4px | Buttons, inputs, tags |
| `--radius-component` | 8px | Cards, panels |
| `--radius-container` | 12px | Modals, login glass card |
| `--radius-pill` | 999px | Rare — status pills only |

### Border Treatment

| Element | Border |
|---------|--------|
| Cards | 1px solid `#E9E9E9` |
| Buttons primary | 1px solid `#CCCCCC` (observed) |
| Inputs | 1px solid `#D9D9D9` |
| Tags | none — background tint only |
| Modals | 1px solid `#DDDDDD` |

Corner philosophy: **Ant Design soft** — 4px controls, 8px cards. Never pill CTAs.

---

## 5. ELEVATION & SHADOWS

| Level | Light Mode | Dark Mode | Use |
|-------|-----------|----------|-----|
| **0** | None | None | All surfaces — flat strategy |
| **1** | None | None | — |
| **2** | None | None | — |
| **3** | None | None | Modals use border only |

Depth comes from `#F7F7F9` canvas vs white `#FAFAFA` cards + 1px borders.

---

## 6. MOTION & INTERACTION

### Personality

Mechanical — Ant Design default. Click, not swoosh. No overshoot.

### Timing

| Type | Duration | Easing | Use |
|------|----------|--------|-----|
| **Micro** | 100ms | `cubic-bezier(0.645, 0.045, 0.355, 1)` | Color change, toggle |
| **Standard** | 150ms | same | Tab switch, dropdown |
| **Emphasis** | 200ms | same | Modal present |

### Interaction States

- Hover primary: `#E5952A` background
- Focus input: 2px orange ring at 20% opacity
- Disabled: 40% opacity, `#F3F3F3` input bg

---

## 7. ICONOGRAPHY

> **⚠ Fallback disclosure.** Preview icons use Phosphor duotone — not NBCB proprietary SVG sprites.

### Observed style

| Attribute | Value |
|-----------|-------|
| Description | Filled gray bodies with blue/red accent fills in custom SVG sprite |
| Stroke weight | filled |
| Corner treatment | soft |
| Fill style | duotone |
| Form language | geometric |
| Visual density | balanced |

### Fallback kit

- **Kit:** Phosphor duotone
- **CDN:** `https://unpkg.com/@phosphor-icons/web@2/src/duotone/style.css`
- **Usage:** `<i class="ph-duotone ph-chart-line"></i>`

### Sizes

| Context | Size |
|---------|------|
| Inline | 14px |
| Buttons | 16px |
| Navigation | 18px |

### Color rule

Nav icons: `#555` default, `#FFA62F` when active. Never multicolor in product UI — monochrome + accent only.

### Don't

- Never use outline Lucide icons — breaks enterprise filled aesthetic.
- Never claim Phosphor icons are NBCB originals.
