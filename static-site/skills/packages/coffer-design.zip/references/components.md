# coffer-design — Components

## 1. BUTTONS

### Variants

| Variant | Background | Text | Border | Radius | Height |
|---------|-----------|------|--------|--------|--------|
| Primary | `#FFA62F` | `#FFFFFF` | 1px `#CCCCCC` | 4px | 40px |
| Secondary | transparent | `#FFA62F` | 2px `#FFA62F` | 4px | 36px |
| Ghost | transparent | `#222222` | none | 4px | auto |
| Destructive | `#F26D44` | `#FFFFFF` | none | 4px | 32px |

### Specs

| Property | Value |
|----------|-------|
| Height (large) | 40px |
| Height (small) | 32px |
| Padding (large) | 0 15px |
| Padding (secondary) | 12px 20px |
| Font | Noto Sans SC 400, 16px (primary) / 14px (secondary) |
| Min touch target | 44px |

### States

| State | Change |
|-------|--------|
| **Hover** | Primary → `#E5952A`; Secondary → `#FFF6EA` bg |
| **Active** | Primary → `#CC8524` |
| **Disabled** | Opacity 0.4, no pointer |
| **Focus** | 2px orange outline at 20% opacity |

---

## 2. CARDS / SURFACES

### Standard Card
- Background: `--surface1` (`#FAFAFA`)
- Border: 1px solid `--border` (`#E9E9E9`)
- Radius: 8px
- Padding: 16px
- Shadow: none

### Glass Card (login/marketing only)
- Background: `rgba(255,253,250,0.7)`
- Border: 2px solid `#FFFFFF`
- Radius: 12px
- Padding: 24px

### KPI Tile
- Same as standard card
- Title: `--caption`, `--text3`
- Value: mono 24px, `--text1`
- Delta: `--success` or `--error`, `--caption`

---

## 3. INPUTS

### Text Field

| Property | Value |
|----------|-------|
| Height | 32px |
| Background | `#FFFFFF` |
| Border (default) | 1px `#D9D9D9` |
| Border (focus) | 1px `#FFA62F` + 2px ring rgba(255,166,47,0.2) |
| Border (error) | 1px `#F26D44` |
| Radius | 4px |
| Padding | 6px 11px 6px 12px |
| Font | Noto Sans SC 13px |
| Placeholder | `--text4` |

### Label
- Above field, 4px gap
- Font: 14px, `--text2`

---

## 4. LISTS / DATA ROWS

### Table Row
- Height: 48px
- Border-bottom: 1px `--border`
- Stripe: `#FAFAFA` on even rows
- Hover: `#FFF6EA` tint
- Selected: `#FFF6EA` bg + orange left border 3px

### Table Header
- Background: `#FAFAFA`
- Font: 12px weight 500, `--text2`
- Sort icon: `--text4`, active `--accent`

---

## 5. NAVIGATION

### Sidebar
- Width: 208px
- Background: `#FAFAFA`
- Item height: 40px
- Item padding: 0 16px
- Default: `--text2`, icon `#555`
- Active: `#FFF6EA` bg, `#FFA62F` text + icon
- Border-right: 1px `--border`

### Top Bar
- Height: 48px
- Background: `#FFFFFF`
- Border-bottom: 1px `--border`
- Breadcrumb: `--text3` / current `--text1`

### Tabs
- Active: weight 700, `--text1`, orange underline 2px
- Inactive: weight 500, `--text4`
- Gap: 16px padding horizontal

---

## 6. TAGS / CHIPS

| Variant | Background | Text | Border |
|---------|-----------|------|--------|
| Default | `#F7F7F9` | `#555` | none |
| Success | `#F0FDF4` | `#52D393` | none |
| Warning | `#FFFBEB` | `#996319` | none |
| Error | `#FEF2F2` | `#F26D44` | none |
| Accent | `#FFF6EA` | `#E5952A` | none |

- Radius: 4px
- Padding: 2px 8px
- Font: 12px

---

## 7. OVERLAYS

### Modal
- Background: `#FFFFFF`
- Border: 1px `#DDDDDD`
- Radius: 12px
- Shadow: none
- Header: 16px padding, border-bottom 1px `--border`
- Footer: right-aligned buttons, 8px gap

### Dropdown
- Background: `#FFFFFF`
- Border: 1px `#E9E9E9`
- Radius: 4px
- Item height: 32px
- Hover item: `#FFF6EA`

---

## 8. STATE PATTERNS

### Empty State
- Icon: 48px duotone, `--text4`
- Title: `--h3`, `--text1`
- Description: `--body`, `--text3`
- CTA: primary button

### Loading
- Ant-style spinner: 16px, `--accent`
- Table: 3 skeleton rows with `#F3F3F3` bars — no shimmer animation

### Error
- Inline alert: `#FEF2F2` bg, `#F26D44` left border 3px
- Icon + message + optional retry link in `--accent`

### Disabled
- Opacity 0.4
- Input bg: `#F3F3F3`
- Cursor: not-allowed
