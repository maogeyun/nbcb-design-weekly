# coffer-design — Platform Mapping

## 1. HTML / CSS / WEB

### Font Loading

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Noto+Sans+SC:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2/src/duotone/style.css">
```

### CSS Custom Properties — Primary Mode (Light)

```css
:root,
[data-theme="light"] {
  --background: #F7F7F9;
  --bg: var(--background);
  --surface1: #FAFAFA;
  --surface2: #E9E9E9;
  --surface3: #DDDDDD;
  --border: #E9E9E9;
  --border-visible: #DDDDDD;
  --text1: #222222;
  --text2: #333333;
  --text3: #555555;
  --text4: #999999;
  --accent: #FFA62F;
  --accent-subtle: #FFF6EA;
  --info: #1890FF;
  --success: #52D393;
  --success-bg: #F0FDF4;
  --warning: #F7D519;
  --warning-bg: #FFFBEB;
  --error: #F26D44;
  --error-bg: #FEF2F2;

  --font-display: "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif;
  --font-body: "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif;
  --font-mono: "JetBrains Mono", ui-monospace, monospace;

  --text-display: 28px;
  --text-h1: 24px;
  --text-h2: 20px;
  --text-h3: 16px;
  --text-body: 14px;
  --text-body-sm: 13px;
  --text-caption: 12px;
  --text-label: 12px;

  --space-2xs: 2px;
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;
  --space-xl: 32px;
  --space-2xl: 48px;
  --space-3xl: 64px;
  --space-4xl: 96px;

  --radius-element: 2px;
  --radius-control: 4px;
  --radius-component: 8px;
  --radius-container: 12px;
  --radius-pill: 999px;

  --ease-fast: cubic-bezier(0.645, 0.045, 0.355, 1);
  --duration-fast: 100ms;
  --duration-medium: 150ms;
  --duration-slow: 200ms;

  --shadow-1: none;
  --shadow-2: none;
  --shadow-3: none;
}
```

### Secondary Mode (Dark)

```css
[data-theme="dark"] {
  --background: #141414;
  --bg: var(--background);
  --surface1: #1A1A1A;
  --surface2: #222222;
  --surface3: #333333;
  --border: #222222;
  --border-visible: #333333;
  --text1: #FAFAFA;
  --text2: #999999;
  --text3: #555555;
  --text4: #333333;
  --accent: #FFA62F;
  --accent-subtle: #805214;
  --success: #52D393;
  --success-bg: #14532D;
  --warning: #F7D519;
  --warning-bg: #78350F;
  --error: #F26D44;
  --error-bg: #7F1D1D;
}
```

### Base Styles

```css
body {
  font-family: var(--font-body);
  font-size: var(--text-body);
  line-height: 1.5715;
  color: var(--text1);
  background: var(--background);
}
.mono { font-family: var(--font-mono); }
```

---

## 2. Tailwind Config

```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
        background: '#F7F7F9',
        surface1: '#FAFAFA',
        surface2: '#E9E9E9',
        border: '#E9E9E9',
        'border-visible': '#DDDDDD',
        text1: '#222222',
        text2: '#333333',
        text3: '#555555',
        text4: '#999999',
        accent: {
          DEFAULT: '#FFA62F',
          subtle: '#FFF6EA',
          hover: '#E5952A',
        },
        success: '#52D393',
        warning: '#F7D519',
        error: '#F26D44',
        info: '#1890FF',
      },
      fontFamily: {
        display: ['"Noto Sans SC"', '"PingFang SC"', '"Microsoft YaHei"', 'sans-serif'],
        body: ['"Noto Sans SC"', '"PingFang SC"', '"Microsoft YaHei"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        control: '4px',
        component: '8px',
        container: '12px',
      },
      boxShadow: {
        card: 'none',
      },
    },
  },
};
```

---

## 3. SwiftUI (iOS companion apps)

```swift
extension Color {
    static let cofferBackground = Color(hex: "#F7F7F9")
    static let cofferSurface1 = Color(hex: "#FAFAFA")
    static let cofferAccent = Color(hex: "#FFA62F")
    static let cofferText1 = Color(hex: "#222222")
    static let cofferText2 = Color(hex: "#333333")
    static let cofferSuccess = Color(hex: "#52D393")
    static let cofferError = Color(hex: "#F26D44")
}

extension Font {
    static func cofferDisplay() -> Font { .system(size: 28, weight: .semibold) }
    static func cofferBody() -> Font { .system(size: 14, weight: .regular) }
    static func cofferMono() -> Font { .system(size: 12, design: .monospaced) }
}
```

Use `RoundedRectangle(cornerRadius: 4, style: .continuous)` for controls, `8` for cards.
